<?php

use Livewire\Volt\Component;
use App\Models\Produk;
use Livewire\WithFileUploads;
use Livewire\Attributes\Validate;
use Illuminate\Support\Facades\Storage;

?>

<div class="content w-100 m-5">
    <h3><span class="text-secondary ">Daftar Produk</span> > <?php echo e($page); ?></h1>
        <form wire:submit.prevent="update" class="w-100 d-flex" enctype="multipart/form-data">
            <div class="row w-100">
                <div class="col-md-12 d-flex w-100 justify-content-between mt-4">
                    <div class="kategori-input w-25">
                        <label for="">Kategori</label>
                        <select wire:model='kategori_id' class="form-select shadow-sm mt-2" name="kategori">
                            <option>Pilih Kategori</option>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($data->id); ?>"><?php echo e($data->nama_kategori); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </select>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['kategori_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                    <div
                        class="nama-barang ms-3 w-100 <?php $__errorArgs = ['nama_produk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <label for="">Nama Barang</label>
                        <input wire:model='nama_produk' name="nama_produk" type="text"
                            class="form-control shadow-sm w-100 mt-2">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['nama_produk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
                <div class="col-md-12 d-flex justify-content-between my-3">
                    <div class="harga-beli w-100">
                        <label for="">Harga Beli</label>
                        <input wire:keydown='change' wire:model.live='harga_beli' name="harga_beli" type="number"
                            class="form-control shadow-sm mt-2">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['harga_beli'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                    <div class="harga-jual ms-3 w-100">
                        <label for="">Harga Jual</label>
                        <input wire:model='harga_jual' name="harga_jual" type="text" readonly
                            class="form-control shadow-sm w-100 mt-2 <?php $__errorArgs = ['kategori'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> ">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['harga_jual'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                    <div class="stock-barang ms-3 w-100">
                        <label for="">Stock Barang</label>
                        <input wire:model='stok' name="stok" type="number"
                            class="form-control shadow-sm w-100 mt-2">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['stok'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
                <div wire:model='image_path' id="upload" class="col-md-12 d-flex justify-content-between my-3">
                    <div class="addimg w-100 d-flex justify-content-center ">
                        <label for="addimg">

                            <!--[if BLOCK]><![endif]--><?php if($image_path): ?>
                                <div style="border: solid"
                                    class="addimg-logo border-primary  d-flex justify-content-center align-items-center">
                                    <img width="200" class="img-fluid " src="<?php echo e($image_path->temporaryUrl()); ?>">
                                </div>
                            <?php else: ?>
                                <div style="border: solid"
                                    class="addimg-logo border-primary d-flex justify-content-center align-items-center">
                                    <div class="text-center">
                                        <img width="150" class="img-default"
                                            src="<?php echo e(asset('storage/fotoproduk/' . $produks->image_path)); ?>"
                                            alt="">
                                        <p class="text-primary"><?php echo e($produks->image_path); ?></p>
                                    </div>
                                </div>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </label>
                        <input wire:model='image_path' name="image_path" id="addimg" type="file"
                            class="form-control shadow-sm w-100 mt-2 py-5" placeholder="">
                    </div>
                </div>
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['image_path'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error">
                        <span class="text-danger"><?php echo e($message); ?></span>
                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                <div class="submit mt-2 d-flex justify-content-end">
                    <div class="ntn-wrappaer w-50 d-flex justify-content-end px-0 ">
                        <a wire:navigate href="/produk" class="btn border-2  border-primary w-25 me-2"
                            type="submit">Batalkan</a>
                        <button class="btn btn-primary w-25 ms-2" type="submit">Simpan</button>
                    </div>
                </div>
            </div>
        </form>
</div><?php /**PATH D:\server\htdocs\laravel\THT-APP\resources\views\livewire/produk/editproduk.blade.php ENDPATH**/ ?>