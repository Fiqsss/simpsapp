<?php $__env->startSection('content'); ?>
    <div class="produk-wrapper d-flex">
        <?php echo $__env->make('components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php if($produks->isEmpty()): ?>
            <div class="content w-100 m-5">
                <div class="search-wrapper">
                    <h3>Daftar Produk</h1>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="search my-4 d-flex">
                                <form class="d-flex" method="GET" action="<?php echo e(route('produk.index')); ?>">
                                    <input type="text" name="keyword" class="form-control w-100" placeholder="Cari Barang">
                                </form>
                                <div class="dropdown mx-3 ">
                                    <a class="btn btn-white dropdown-toggle border-1 border-dark shadow-sm" href="#"
                                        role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                        <?php echo e($kategori_select ? $kategori_select->nama_kategori : 'Semua'); ?>

                                    </a>
                                    <ul class="dropdown-menu">
                                        <li><a class="dropdown-item" href="<?php echo e(route('produk.index')); ?>">Semua</a></li>
                                        <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <a class="dropdown-item"
                                                    href="<?php echo e(route('produk.index', ['kategori' => $data->id])); ?>"><?php echo e($data->nama_kategori); ?></a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </div>
                            <div class="fitures-wrapper">
                                <a href="<?php echo e(route('produk.export', ['keyword' => request('keyword'), 'kategori' => request('kategori')])); ?>"
                                    class="btn btn-success">
                                    <img class="mb-1" style="width: 1rem; height: 1rem"
                                        src="<?php echo e(asset('assets/img/components/MicrosoftExcelLogo.png')); ?>" alt="">
                                    Export
                                    Excel</a>
                                <a href="/produk/create" class="btn btn-danger"><img
                                        src="<?php echo e(asset('assets/img/components/PlusCircle.png')); ?>" alt=""> Tambah
                                    Produk</a>
                            </div>
                        </div>
                </div>
                <table class="table table-borderless shadow-sm">
                    <thead>
                        <tr style="background-color:#F9F9F9 !important" class="table-active">
                            <th>No</th>
                            <th scope="col">Image</th>
                            <th scope="col">Nama Produk</th>
                            <th scope="col">Kategori Produk</th>
                            <th scope="col">Harga Beli (Rp)</th>
                            <th scope="col">Harga Jual (Rp)</th>
                            <th scope="col">Stock Produk</th>
                            <th scope="col">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="">
                        <tr class="text-center w-100">
                            <td colspan="8">
                                <h3>Tidak ada data produk</h3>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="content w-100 m-5">
                <div class="search-wrapper">
                    <h3>Daftar Produk</h1>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="search my-4 d-flex">
                                <form class="d-flex" method="GET" action="<?php echo e(route('produk.index')); ?>">
                                    
                                    <input type="text" name="keyword" class="form-control w-100"
                                        placeholder="Cari Barang">

                                </form>
                                <div class="dropdown mx-3 ">
                                    <a class="btn btn-white dropdown-toggle border-1 border-dark shadow-sm" href="#"
                                        role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                        <?php echo e($kategori_select ? $kategori_select->nama_kategori : 'Semua'); ?>

                                    </a>
                                    <ul class="dropdown-menu">
                                        <li><a class="dropdown-item" href="<?php echo e(route('produk.index')); ?>">Semua</a></li>
                                        <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <a class="dropdown-item"
                                                    href="<?php echo e(route('produk.index', ['kategori' => $data->id])); ?>"><?php echo e($data->nama_kategori); ?></a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </div>
                            <div class="fitures-wrapper">
                                <a href="<?php echo e(route('produk.export', ['keyword' => request('keyword'), 'kategori' => request('kategori')])); ?>"
                                    class="btn btn-success">
                                    <img class="mb-1" style="width: 1rem; height: 1rem"
                                        src="<?php echo e(asset('assets/img/components/MicrosoftExcelLogo.png')); ?>" alt="">
                                    Export
                                    Excel</a>
                                <a href="/produk/create" class="btn btn-danger"><img class="mb-1"
                                        style="width: 1rem; height: 1rem"
                                        src="<?php echo e(asset('assets/img/components/PlusCircle.png')); ?>" alt=""> Tambah
                                    Produk</a>
                            </div>
                        </div>
                </div>
                <table class="table table-borderless shadow-sm">
                    <thead>
                        <tr style="background-color:#F9F9F9 !important" class="table-active">
                            <th>No</th>
                            <th scope="col">Image</th>
                            <th scope="col">Nama Produk</th>
                            <th scope="col">Kategori Produk</th>
                            <th scope="col">Harga Beli (Rp)</th>
                            <th scope="col">Harga Jual (Rp)</th>
                            <th scope="col">Stock Produk</th>
                            <th scope="col">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="">
                        <?php $__currentLoopData = $produks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key + 1); ?></td>
                                <td class="text-center " style="width: 100px;"><img class="img-fluid w-50"
                                        src="../../../storage/app/public/fotoproduk/bas.jpg" alt="">
                                </td>
                                <td><?php echo e($data->nama_produk); ?></td>
                                <td><?php echo e($data->kategori->nama_kategori); ?></td>
                                <td>Rp.<?php echo e(number_format($data->harga_beli, 0, ',', '.')); ?></td>
                                <td>Rp.<?php echo e(number_format($data->harga_jual, 0, ',', '.')); ?></td>
                                <td><?php echo e($data->stok); ?></td>
                                <td>
                                    <a href="<?php echo e(route('produk.edit', $data->id)); ?>" class="btn btn-sm"><img
                                            src="<?php echo e(asset('assets/img/components/edit.png')); ?>" alt=""></a>
                                    <a class="btn btn-sm" data-bs-toggle="modal"
                                        data-bs-target="#delete<?php echo e($data->id); ?>"><img
                                            src="<?php echo e(asset('assets/img/components/delete.png')); ?>" alt=""></a>
                                </td>
                                <?php echo $__env->make('produk.deleteproduk', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php echo e($produks->withQueryString()->links('pagination::bootstrap-5')); ?>

            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        <?php if(session('success')): ?>
            swal.fire(
                'Berhasil!',
                '<?php echo e(session('success')); ?>',
                'success'
            )
        <?php endif; ?>
        <?php if($errors->any()): ?>
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: '<?php echo e($errors->first()); ?>',
            });
        <?php endif; ?>
    </script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const sidebar = document.querySelector('.sidebar');
            const toggleButton = document.querySelector('.sidebar .header button');

            toggleButton.addEventListener('click', function() {
                sidebar.classList.toggle('hidden'); // Togle kelas "hidden" pada sidebar saat tombol diklik
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\server\htdocs\laravel\THT-APP\resources\views/produk/index.blade.php ENDPATH**/ ?>