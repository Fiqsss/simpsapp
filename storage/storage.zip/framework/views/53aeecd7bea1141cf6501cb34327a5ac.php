<?php $__env->startSection('content'); ?>
<div class="produk-wrapper d-flex">
    <?php echo $__env->make('components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="content w-100 m-5">
        <div class="row">
            <div class="col-md-12">
                <img width="150" src="<?php echo e(asset('storage/userimg/' . $user->userimg)); ?>" alt="">
                <h2 class="mt-4"><?php echo e($user->name); ?></h2>
            </div>
            <div class="col-md-12 d-flex mt-3">
                <div class="kandidat w-100 me-3">
                    <label for="">Nama Kandidat</label>
                    <input placeholder="@ <?php echo e($user->name); ?>" readonly class="form-control w-100 mt-2" type="text">
                </div>
                <div class="posisi-kandidat w-100 ms-3">
                    <label for="">Posisi Kandidat</label>
                    <input placeholder="</> <?php echo e($user->posisi); ?>" readonly class="form-control w-100 mt-2" type="text">
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\server\htdocs\laravel\THT-APP\resources\views/profile/index.blade.php ENDPATH**/ ?>