<?php $__env->startSection('content'); ?>
    <div class="produk-wrapper d-flex">
        <?php echo $__env->make('components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('produk.tambahproduk', ['page' => $page,'kategoris' => $kategoris]);

$__html = app('livewire')->mount($__name, $__params, 'lw-1696478452-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"
        integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
    <script>
        <?php if(session('success')): ?>
            swal.fire(
                'Berhasil!',
                '<?php echo e(session('success')); ?>',
                'success'
            )
        <?php endif; ?>
        <?php if($errors->any()): ?>
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: '<?php echo e($errors->first()); ?>',
            });
        <?php endif; ?>
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\server\htdocs\laravel\THT-APP\resources\views/produk/tambahproduk.blade.php ENDPATH**/ ?>