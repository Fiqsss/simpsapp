<?php $__env->startSection('content'); ?>
<div class="container mx-auto bg-white">
    <div style="height: 100vh" class="w-100 d-flex justify-content-center  align-items-center ">
        <div class="login-wrapper row shadow ">
            <div class="col-md-6 d-flex justify-content-center align-items-center ">
                <div class="w-100 px-5">
                    <div class="header-login ">
                        <h4 class="text-center"><i class="fas fa-shopping-bag"></i> SIMS Web App</h4>
                        <h3 class="mt-4 text-center">Masuk atau buat akun <br> untuk memulai</h3>
                    </div>
                    <form class="mt-5 px-5" method="post" action="/login">
                        <?php echo csrf_field(); ?>
                        <input name="email"
                            class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="email"
                            placeholder="@ Masukan email anda">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <input name="password" class="form-control mt-4 <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="password" placeholder="Masukan Password anda">

                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <button class="btn btn-danger text-white w-100 mt-5">Masuk</button>
                    </form>
                </div>
            </div>
            <div class="col-md-6 img-fluid d-flex justify-content-center align-items-center px-0">
                <img class="img-fluid" src="<?php echo e(asset('assets/img/components/Frame 98699.png')); ?>" alt="">
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\server\htdocs\laravel\THT-APP\resources\views/auth/login.blade.php ENDPATH**/ ?>